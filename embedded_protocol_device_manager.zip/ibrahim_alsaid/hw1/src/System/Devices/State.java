package System.Devices;

public enum State {
    ON,
    OFF
}