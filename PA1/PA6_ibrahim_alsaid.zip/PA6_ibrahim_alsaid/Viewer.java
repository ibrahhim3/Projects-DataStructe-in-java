import java.util.ArrayList;
import java.util.List;
class Viewer implements Observer {//the viewer class <observer>
    private Media current;
    protected List<Media> mediaList = new ArrayList<>();

    @Override
    public void update(Media media) {
        if (media instanceof NonPlayable) {
            mediaList.add(media);
        }
    }

    @Override
    public void removeTheUpdate(Media media) {
        mediaList.remove(media);
        if (current == media) {
            current = null;
        }
    }

    public void setDataset(Dataset dataset) {
        this.mediaList = new ArrayList<>();
        for (Media media : dataset.getMediaList()) {
            if (media instanceof NonPlayable) {
                mediaList.add(media);
            }
        }
        if (!mediaList.isEmpty()) {
            current = mediaList.get(0);
        }
    }

    public void show_list() {
        for (Media media : mediaList) {
            media.info();
        }
    }

    public NonPlayable currently_viewing() {//return the current obj running 
        if (current == null && !mediaList.isEmpty()) {
            current = mediaList.get(0);
        }
        return (NonPlayable) current;
    }

    public void next(String typeOftheobj) {//to get the next obj
        int index = mediaList.indexOf(current);
        for (int i = 1; i <= mediaList.size(); i++) {
            Media media = mediaList.get((index + i) % mediaList.size());
            if (typeOftheobj.equalsIgnoreCase("Text") && media instanceof Text) {
                current = media;
                return;
            } else if (typeOftheobj.equalsIgnoreCase("Image") && media instanceof Image) {
                current = media;
                return;
            }
        }
    }

    public void previous(String typeOftheobj) {// to get the previous obj
        int index = mediaList.indexOf(current);
        for (int i = 1; i <= mediaList.size(); i++) {
            Media media = mediaList.get((index - i + mediaList.size()) % mediaList.size());
            if (typeOftheobj.equalsIgnoreCase("Text") && media instanceof Text) {
                current = media;
                return;
            } else if (typeOftheobj.equalsIgnoreCase("Image") && media instanceof Image) {
                current = media;
                return;
            }
        }
    }
}
