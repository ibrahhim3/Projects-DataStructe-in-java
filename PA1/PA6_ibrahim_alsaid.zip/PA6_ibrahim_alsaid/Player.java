import java.util.ArrayList;
import java.util.List;
class Player implements Observer {// the play class  <observer>
    private Media current;
    protected List<Media> mediaList = new ArrayList<>();

    @Override
    public void update(Media media) {
        if (media instanceof Playable) {
            mediaList.add(media);
        }
    }

    @Override
    public void removeTheUpdate(Media media) {
        mediaList.remove(media);
        if (current == media) {
            current = null;
        }
    }

    public void setDataset(Dataset dataset) {
        this.mediaList = new ArrayList<>();
        for (Media media : dataset.getMediaList()) {
            if (media instanceof Playable) {
                mediaList.add(media);
            }
        }
        if (!mediaList.isEmpty()) {
            current = mediaList.get(0);
        }
    }

    public void show_list() {
        for (Media media : mediaList) {
            media.info();
        }
    }

    public Playable currently_playing() {
        if (current == null && !mediaList.isEmpty()) {//return the current obj playing
            current = mediaList.get(0);
        }
        return (Playable) current;
    }

    public void next(String typeOftheobj) {//to knw the next obj
        int index = mediaList.indexOf(current);
        for (int i = 1; i <= mediaList.size(); i++) {
            Media media = mediaList.get((index + i) % mediaList.size());
            if (typeOftheobj.equalsIgnoreCase("Audio") && media instanceof Audio) {
                current = media;
                return;
            } else if (typeOftheobj.equalsIgnoreCase("Video") && media instanceof Video) {
                current = media;
                return;
            }
        }
    }

    public void previous(String typeOftheobj) {//to know the previous obj
        int index = mediaList.indexOf(current);
        for (int i = 1; i <= mediaList.size(); i++) {
            Media media = mediaList.get((index - i + mediaList.size()) % mediaList.size());
            if (typeOftheobj.equalsIgnoreCase("Audio") && media instanceof Audio) {
                current = media;
                return;
            } else if (typeOftheobj.equalsIgnoreCase("Video") && media instanceof Video) {
                current = media;
                return;
            }
        }
    }
}
