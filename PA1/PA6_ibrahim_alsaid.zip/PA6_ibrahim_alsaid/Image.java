class Image extends Media implements Visual, NonPlayable {
    private String Info;

    public Image(String name, String dimensionInfo, String otherInfo) {
        super(name, otherInfo);
        this.Info = dimensionInfo;
    }

    @Override
    public void info() {
        System.out.println("Image: " + name + ", Dimensions: " + Info + ", Info: " + otherInfo);
    }

}
