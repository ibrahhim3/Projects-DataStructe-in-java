
interface Visual {
}

interface NonVisual {
}

interface Playable {
    void info();
}

interface NonPlayable {
    void info();
}


public class K {
    public static void main(String[] args) {
        Dataset ds = new Dataset();
    
        Player p1 = new Player();
        Player p2 = new Player();
        Viewer v1 = new Viewer();
    
        ds.register(p1);
        ds.register(p2);
        ds.register(v1);
        
        ds.add(new Audio("audioname1", "duration1", "other info1"));
        ds.add(new Audio("audioname2", "duration2", "other info2"));
        
        ds.add(new Video("videoname1", "duration3", "other info3"));
        ds.add(new Video("videoname2", "duration2", "other info2"));

        ds.add(new Text("textname1", "other info1"));
        ds.add(new Text("textname2", "other info2"));

        ds.add(new Image("imagename1", "dimensioninfo1", "other info1"));
        ds.add(new Image("imagename2", "dimensioninfo2", "other info2"));

        Playable po= p1.currently_playing();
        System.out.printf("the current:\n");
        po.info();
        System.out.printf("the list :\n");
        p1.show_list();
        ds.remove((Media) po);
        System.out.printf("the list after removing the current of the playable obj:\n");
        p1.show_list();

        NonPlayable p= v1.currently_viewing();
        System.out.printf("the current:\n");
        p.info();
        System.out.printf("the list :\n");
        v1.show_list();
        ds.remove((Media) p);
        System.out.printf("the list after removing the current of the nonplayalbe obj:\n");
        v1.show_list();

        System.out.printf("next for playable (Video):\n");
        p1.next("Video");
        po= p1.currently_playing();
        po.info();
        System.out.printf("next for playable (Video):\n");
        p1.next("Video");
        po= p1.currently_playing();
        po.info();
        System.out.printf("prev for playable (Video):\n");
        p1.previous("Video");
        po= p1.currently_playing();
        po.info();

    }

}


