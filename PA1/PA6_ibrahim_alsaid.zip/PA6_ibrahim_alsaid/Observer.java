interface Observer {
    void update(Media media);
    void removeTheUpdate(Media media);
}
