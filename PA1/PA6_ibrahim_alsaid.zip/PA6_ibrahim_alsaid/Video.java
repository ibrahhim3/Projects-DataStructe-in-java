
class Video extends Media implements Visual, Playable {
    private String duration;

    public Video(String name, String duration, String otherInfo) {
        super(name, otherInfo);
        this.duration = duration;
    }

    @Override
    public void info() {
        System.out.println("Video: " + name + ", Duration: " + duration + ", Info: " + otherInfo);
    }
}