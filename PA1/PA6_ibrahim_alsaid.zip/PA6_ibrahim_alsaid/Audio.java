class Audio extends Media implements NonVisual, Playable {
    private String duration;

    public Audio(String name, String duration, String otherInfo) {
        super(name, otherInfo);
        this.duration = duration;
    }

    @Override
    public void info() {
        System.out.println("Audio: " + name + ", Duration: " + duration + ", Info: " + otherInfo);
    }


}

