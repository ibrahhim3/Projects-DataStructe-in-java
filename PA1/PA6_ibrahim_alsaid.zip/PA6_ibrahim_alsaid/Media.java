class Media {//the base class 
    protected String name;
    protected String otherInfo;

    public Media(String name, String otherInfo) {
        this.name = name;
        this.otherInfo = otherInfo;
    }

    // default implementation of the info method
    public void info() {
        System.out.println("Media: " + name + ", Info: " + otherInfo);
    }
}
