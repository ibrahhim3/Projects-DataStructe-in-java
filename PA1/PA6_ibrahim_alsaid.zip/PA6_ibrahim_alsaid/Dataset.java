import java.util.ArrayList;
import java.util.List;

class Dataset {
    private List<Media> mediaList;
    private List<Player> players;
    private List<Viewer> viewers;

    public Dataset() {//defult constracter
        mediaList = new ArrayList<>();
        players = new ArrayList<>();
        viewers = new ArrayList<>();
    }

    public void add(Media media) {
        mediaList.add(media);
        notifyTheObservers(media, true);
    }

    public void remove(Media media) {
        mediaList.remove(media);
        notifyTheObservers(media, false); 
    }

    private void notifyTheObservers(Media media, boolean Isadded) {// this func to notify the observer
        if (media instanceof Playable) {
            for (Player player : players) {
                if (Isadded) {
                    player.update(media);
                } else {
                    player.removeTheUpdate(media);
                }
            }
        } else {
            for (Viewer viewer : viewers) {
                if (Isadded) {
                    viewer.update(media);
                } else {
                    viewer.removeTheUpdate(media);
                }
            }
        }
    }

    public void register(Player player) {//register for the player
        players.add(player);
        player.setDataset(this);
    }

    public void register(Viewer viewer) {//register for the viewer
        viewers.add(viewer);
        viewer.setDataset(this);
    }

    public void unregistering(Player player) {
        players.remove(player);
    }

    public void unregistering(Viewer viewer) {
        viewers.remove(viewer);
    }

    public List<Media> getMediaList() {
        return mediaList;
    }
}
